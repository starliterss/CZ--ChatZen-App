Hello all the contributors !!
<br>
I am glad to see that you are interested to work in this repo.
 
To contribute for the project just follow these easy steps:
<br>
Step 1: fork it to your GitHub
<br>
Step 2: clone the repo to your code editor (command: git clone <Repo's URL>)
<br>
Step 3: work on the issue you want and make changes in the code
<br>
Step 4: create a new branch (command: git checkout -b "branch name")
<br>
Step 5: Add your changes (command: git add .)
<br>
Step 6: Commit your changes (git commit -m "message")
<br>
Step 7: Push your changes (git push origin BranchName)
<br>
Step 8: go to the GitHub and click on "compare and pull request"
<br>

Happy Contributing !!
