# Chatzen
A realtime chat application made with kotlin which uses Firebase to store data at the backend.
- You can securly send messages to your friends
- You can also make video calls to your friends by creating a secured and private room with unique id
